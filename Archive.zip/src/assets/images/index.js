import fig1 from "/public_assets/images/fig1.jpg";
import fig2 from "/public_assets/images/fig2.jpg";
import fig3 from "/public_assets/images/fig3.jpg";
import fig4 from "/public_assets/images/fig4.jpg";

export default {
  fig1,
  fig2,
  fig3,
  fig4,
};
