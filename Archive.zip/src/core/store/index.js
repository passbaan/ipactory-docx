import { createStore } from "vuex";

import intialize from "./intialize.module";

export default createStore({
  modules: {
    intialize,
  },
});
